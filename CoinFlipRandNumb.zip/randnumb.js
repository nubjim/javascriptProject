function randTen()
{
  var numb = Math.floor((Math.random() * 10) + 1);
  document.getElementById("res").innerHTML = numb;
}
function randHundred()
{
  var numb = Math.floor((Math.random() * 100) + 1);
  document.getElementById("res").innerHTML = numb;
}
